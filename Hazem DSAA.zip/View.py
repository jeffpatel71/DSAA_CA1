import re
### Name : Hazem Bin Ryaz Patel
### Admission Number : 2200550
### Class : DAAA/FT/2B/07

class View:
    def __init__(self):
        self.selection = None

    def display_menu(self):
        while True:
            print("""Please select your choice: (1,2,3,4,5,6,7,8):
                            1. Encrypt/Decrypt Message
                            2. Encrypt/Decrypt File
                            3. Analyze letter frequency distribution
                            4. Infer Caesar cipher key from file
                            5. Analyze and sort encrypted files
                            6. Batch Encrypt/Decrypt Files
                            7. Compare frequency distribution with English languagec
                            8. Exit program""")
            self.selection = input("Enter choice: ")
            if self.selection in ["1", "2", "3", "4", "5", "6", "7", "8"]:
                return self.selection
            else:
                print("Invalid choice. Please enter a valid option (1-8).\n")
    
    def display_encryption(self, message, encrypted):
        print("Original message: ", message)
        print("Encrypted message: ", encrypted)
    
    def display_key(self, key):
        print("The Inferred key is: ", key)
    
    def display_frequency(self, frequency_diff, percentage_similarity):

        print("The difference between the text's frequency distribution and the English language frequency distribution is:", frequency_diff)
        print("The text's frequency distribution is", percentage_similarity, "% similar to the English language frequency distribution.")